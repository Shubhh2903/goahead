import { copyFile, mkdir, readdir, rm } from "node:fs/promises";
import { extname } from "node:path";

const sourceRoot = new URL("../web/", import.meta.url);
const outputRoot = new URL("../dist/", import.meta.url);
const copiedExtensions = new Set([".html", ".json", ".css", ".svg", ".png", ".js", ".wasm"]);
const excludedPaths = new Set(["stream/transport/web_socket.js"]);

await copyDirectory(sourceRoot, outputRoot);
await Promise.all([
  rm(new URL("stream/audio/", outputRoot), { force: true, recursive: true }),
  rm(new URL("stream/transport/web_socket.js", outputRoot), { force: true }),
]);

async function copyDirectory(source, output, relativeDirectory = "") {
  await mkdir(output, { recursive: true });
  for (const entry of await readdir(source, { withFileTypes: true })) {
    const relativePath = `${relativeDirectory}${entry.name}`;
    if (relativePath === "stream/audio" || excludedPaths.has(relativePath)) {
      continue;
    }
    const sourcePath = new URL(entry.name, source);
    const outputPath = new URL(entry.name, output);
    if (entry.isDirectory()) {
      await copyDirectory(new URL(`${entry.name}/`, source), new URL(`${entry.name}/`, output), `${relativePath}/`);
    } else if (copiedExtensions.has(extname(entry.name))) {
      await copyFile(sourcePath, outputPath);
    }
  }
}
